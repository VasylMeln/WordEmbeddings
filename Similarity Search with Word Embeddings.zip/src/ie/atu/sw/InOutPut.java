package ie.atu.sw;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class InOutPut {
	
	public static String[][] in (String incomingPath) throws IOException {
		//a method for parsing a file and returning data from it
		
		long count = 0;
	
		
		File db = new File(incomingPath);
		String absPath = db.getAbsolutePath(); //found in https://stackoverflow.com/questions/14209085/how-to-define-a-relative-path-in-java
		
		//tested with the local path "D:/Programs/Eclipse/WORKING files/WE2/src/ie/atu/sw/word-embeddings.txt"
		
		try { 
		Path path = Paths.get(absPath); //found in https://docs.oracle.com/javase/8/docs/api/java/nio/file/Paths.html 
		
		count = Files.lines(path).count(); 
		
		} catch (NoSuchFileException | FileNotFoundException e ) {
			System.out.println("File path entered incorrectly");
			
		}
		
		BufferedReader br = new BufferedReader(new FileReader(absPath));
		
		String [][] data = new String [(int) count][];
		for (int i = 0; i < count; i++) {
			data[i] = br.readLine().split(",");	
		}
		br.close();
		return data;
		
	} 
	
	public static void out (String [] closestW, double[] closestD, String Path) {
		// a method that takes closest words with their corresponding distances and writes them into the output file created
		
		File db = new File(Path);
		String absPath = db.getAbsolutePath();
		
		try {
	        BufferedWriter out = new BufferedWriter(new FileWriter(absPath));
	       
	        out.write("The closest words are: \n \n");
	        for (int i = 0; i < closestD.length; i++) {
	        	out.write("word " + (i+1) + ": " + closestW[i] + "    \t-----\t" + "\t distance: \t-----\t" + closestD[i] + "\n");
	        }
	        
	        out.close();
	    } catch (IOException e) {
	    }
	
		
		
		System.out.println("File created at " + absPath);
	}
	
	public static int[] wordMatch (String input, String[] list) {
		// returns indices of the words found in the dictionary
		
		String[] userWords = input.split(" ");
		int len = userWords.length;
		int [] match = new int[len];
		
		System.out.println("Number of words entered:" + userWords.length);
		
		try { 
			for (int j=0; j<len; j++) {
				for (int i=0; i<list.length; i++) {
					if (userWords[j].equals(list[i])) {
						match[j]=i;
					}
				}
			}
			
		
		} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
		return match;
		
		
		
	}
 	
	
	
	public static int singleWordMatch (String input, String[] list) {
		// returns indices of the words found in the dictionary
		
		int match = -1;
		
		try { 
				for (int i=0; i<list.length; i++) {
					if (input.equals(list[i])) {
						match = i;
					}
				}
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		
		return match;
		
	}
}
