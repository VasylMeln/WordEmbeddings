package ie.atu.sw;
import java.lang.Math;

public class Algos {
	private double[] centered; //averaged vector;
	
	
	private double[][] ue; //for Used Embeddings
	
	public Algos (int[] indices, double[][] embeddings) {
		double[][] temp_ue = new double [indices.length][];
		
		for (int i=0; i<indices.length; i++) {
			temp_ue[i] = embeddings[indices[i]];
		}
		ue = temp_ue;
		
		
		
		centered = new double[embeddings[0].length]; //inspired by https://stackoverflow.com/questions/46985199/calculate-averages-of-rows-in-a-data-table-using-arrays-in-java
		//System.out.println("embeddings.length" + embeddings[0].length);
		for (int j=0; j<embeddings[0].length; j++) {
			//System.out.print(j + "\n");
			double row_sum = 0;
			 for (double[] line : ue) {
				 row_sum += line[j];
			 }
			 centered[j] = row_sum / ue.length;
			 //System.out.println(centered[j]);
		}
		
	
	
	}
	
	
	public Algos (int index, double[][] embeddings) {
		
		centered = embeddings[index];
		
	
	
	}
	
	
	
	public double distance(double[] emb_line) {
		double temp_dp=0; // dotproduct
		double sqr_usr=0;
		double sqr_emb_line=0;
		double distance;
		for (int i=0; i<centered.length; i++) {
			temp_dp+= centered[i]*emb_line[i];
			sqr_usr+= centered[i]*centered[i];
			sqr_emb_line+= emb_line[i]*emb_line[i];
		}
		//System.out.println("dotproduct " + temp_dp);
		distance = temp_dp/Math.sqrt(sqr_usr*sqr_emb_line);
		return distance;
		//return dotprod; 
	}
}
