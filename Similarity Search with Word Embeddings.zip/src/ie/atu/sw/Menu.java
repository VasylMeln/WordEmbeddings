package ie.atu.sw;



import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Menu {
	
	private static final int FEATURES = 50; //the program uses fixed number of Features or Weights
	private Scanner s; //reserves a variable for a scanner
	private boolean keepRunning=true;
	private String outLine = "./out.txt";
	String [][]rawData; //reserves a variable for 2 dimensional array of strings to be used as a raw data storage  
	protected static String []words; // array of strings to contain words parsed from the file
	protected double [][]weights; // 2 dimensional array of doubles to contain 50 Features or Weights per each.
	private int[] matched_indices; // array of int to contain indices of the user-entered words that were successfully found in the file.
	private int noOfClosestWords = 0; // number of closest words that the user would like to save in the output file.
	private String[] closestWords; // String array of the words closest to those entered by the user.
	int size = 0; // number of words in the parsed file. 
	
	
	public Menu() {
	s = new Scanner(System.in);
	}
	
	public void start() throws IOException {
		// starts the menu and executes user options; 
		
		while (keepRunning) {
			showPoints();
			
			
			switch(s.nextLine()) {
			case "1" -> load();
			case "2" -> {write();}
			case "3" -> {Search(); }
			case "4" -> {specifyNumberOfWordsToSave(); saveClosestWords();}
			case "5" -> {System.out.println("Let's play"); play();}
			case "6" -> {keepRunning = false; 
			System.out.println("Quitting the app. Bye!");}
			}
			
			
		}
	}
	private void load() throws IOException {
		// loads a file and creates 2 lists: one for words and another one for weights (coefficients); 
		
		System.out.println("Specify Embedding File");
		
		String inLine = s.nextLine();
		//System.out.println(inLine);
		rawData = InOutPut.in(inLine);
		size = rawData.length;
		if (size>0) System.out.println("The file has been loaded");
		
		String [] temp_words = new String [size];
		double [][] temp_weights = new double [size][FEATURES];
		
		for (int i = 0; i < size; i++) {
			temp_words[i]=rawData[i][0];
			
			for (int j=0; j<FEATURES; j++) {
				temp_weights[i][j] = Double.parseDouble(rawData[i][j+1]);
			}
		}
		words = temp_words;
		weights = temp_weights;
		
		//System.out.println(words[12]);
		//for (int i=0;i<FEATURES; i++) {
		//System.out.println(weights[12][i]);}
	}
	
	
	private void write() throws IOException {
		//saves the path and name for the file that is going to contain the program's output, ./out.txt by default
		
		System.out.println("Enter the Output File Name:");
		
		outLine = s.nextLine();
		System.out.println("the file will be saved at" + outLine);
	}
	private void Search() {
		// searches for the user entered words and assigns all matched indices to the corresponding variable;
		
		System.out.print("Enter one or several words \n");
		//System.out.println(words.length);
		String input = s.nextLine().toLowerCase();
		matched_indices = InOutPut.wordMatch(input, words);
		
		
	}
	
	private void specifyNumberOfWordsToSave() {
		//self-explanatory, lets the user specify the number of words that will be saved in the file created
		
		System.out.print("Please enter a number: \n");
		//System.out.println(words.length);
		try 
		{noOfClosestWords = Integer.parseInt(s.nextLine());
			closestWords = new String[noOfClosestWords];
		} catch (NumberFormatException e) {
			System.out.println("Enter correct number");
		}
		
	}
	
	private void saveClosestWords() {
		//saves certain number of words to the file specified by the user
		
		double[] closestDist = new double[noOfClosestWords];
		double[] distances = new double[size]; 
		double[] dist_sorted = new double[size]; 
		Algos calcDist = new Algos(matched_indices, weights);
		
		for (int i=0; i<size; i++) { 
			distances[i] = calcDist.distance(weights[i]);
			dist_sorted[i] = calcDist.distance(weights[i]);
			//System.out.println("distance \t" + words[i] + " = " + distances[i]);
		}
		
		Arrays.sort(dist_sorted); 
		int a = 0; //simple counter for IF below
		for (int i = (size-matched_indices.length)-noOfClosestWords; i<size-matched_indices.length; i++) { //to change 10 to size
			for (int j = 0; j<size; j++) {
				if (dist_sorted[i] == distances[j]) {
					closestDist[a] = distances[j];
					//System.out.println(a);
					closestWords[a++] = words[j];
					//System.out.println(a);
					//System.out.println(words[j]);
				}
			}
		}
		InOutPut.out(closestWords, closestDist, outLine);
		
	}
	
	private void play() {
		// Method for a simple game based on the program's logic of finding the shortest distance between words. Inspired by Semantle. 
		// implements ThreadLocalRandom https://www.baeldung.com/java-thread-local-random
		if (size>0) {
		int index = ThreadLocalRandom.current().nextInt(size);
		String wordToGuess = words[index];
		
		Algos game_dist = new Algos(index, weights);
		//System.out.println(wordToGuess);
		int attempts = 1;
		String guess;
		System.out.println("You have 30 attempts to guess the word that was randomly picked. \n"
				+ "the correct word is 100 C degrees. Boil it! Good luck!");
		
		double prev_distance = -1.0; // previous distance value
		double cur_distance; // current distance between 2 words
		int index_guessed = 0;
		while (attempts <= 30) {
			System.out.println("Your attempt number:" + attempts);
			System.out.println("Enter your word:");
			guess = s.nextLine().toLowerCase();
			index_guessed = InOutPut.singleWordMatch(guess, words);
			if (index_guessed == -1) {
				System.out.println("the word is not in the list, try another one");
				continue;
			}
			cur_distance = game_dist.distance(weights[index_guessed]);
			
			if (guess.equals(wordToGuess)) {
				System.out.println("Marvellous! You won!");
				return;
			} else if (cur_distance > prev_distance) {
				System.out.println("Warmer!" + cur_distance*100 + " C degrees now");
				prev_distance = cur_distance;
				
			} else if (cur_distance == prev_distance) {
				System.out.println("Same! Keep trying " + cur_distance*100 + " C degrees now");
				prev_distance = cur_distance;
				
			} else if  (cur_distance < prev_distance) {
				System.out.println("Colder! Keep trying " + cur_distance*100 + " C degrees now");
				prev_distance = cur_distance;
			}
			
			attempts++;
			
		}
		System.out.println("You Lost! The correct word was " + wordToGuess);
		} else System.out.println("Don't forget to load the Word Embeddings file!");
	}
	
	private void showPoints() {
		
				System.out.println(ConsoleColour.WHITE);
				System.out.println("************************************************************");
				System.out.println("*     ATU - Dept. of Computer Science & Applied Physics    *");
				System.out.println("*                                                          *");
				System.out.println("*          Similarity Search with Word Embeddings          *");
				System.out.println("*                                                          *");
				System.out.println("************************************************************");
				System.out.println("(1) Load file");
				System.out.println("(2) Specify an Output File (default: ./out.txt)");
				System.out.println("(3) Enter a Word or Text");
				System.out.println("(4) Specify number of closest words");
				System.out.println("(5) Want to play a game?");
				System.out.println("(6) Quit");
				
				//Output a menu of options and solicit text from the user
				System.out.print(ConsoleColour.BLACK_BOLD_BRIGHT);
				System.out.print("Select Option [1-6]>");
				System.out.println();
	}
	
}

